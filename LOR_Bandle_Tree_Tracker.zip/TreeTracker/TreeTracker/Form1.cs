using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// This is the code for your desktop app.
// Press Ctrl+F5 (or go to Debug > Start Without Debugging) to run your app.

namespace TreeTracker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Click on the link below to continue learning how to build a desktop app using WinForms!
            System.Diagnostics.Process.Start("http://aka.ms/dotnet-get-started-desktop");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.BackColor = Color.Red;
            pictureBox2.BackColor = Color.Red;
            pictureBox3.BackColor = Color.Red;
            pictureBox4.BackColor = Color.Red;
            pictureBox5.BackColor = Color.Red;
            pictureBox6.BackColor = Color.Red;
            pictureBox7.BackColor = Color.Red;
            pictureBox8.BackColor = Color.Red;
            pictureBox9.BackColor = Color.Red;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (pictureBox1.BackColor != Color.Green)
            {
                pictureBox1.BackColor = Color.Green;
            }
            else
            {
                pictureBox1.BackColor = Color.Red;
            }
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            if (pictureBox6.BackColor != Color.Green)
            {
                pictureBox6.BackColor = Color.Green;
            }
            else
            {
                pictureBox6.BackColor = Color.Red;
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (pictureBox5.BackColor != Color.Green)
            {
                pictureBox5.BackColor = Color.Green;
            }
            else
            {
                pictureBox5.BackColor = Color.Red;
            }
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            if (pictureBox8.BackColor != Color.Green)
            {
                pictureBox8.BackColor = Color.Green;
            }
            else
            {
                pictureBox8.BackColor = Color.Red;
            }
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            if (pictureBox9.BackColor != Color.Green)
            {
                pictureBox9.BackColor = Color.Green;
            }
            else
            {
                pictureBox9.BackColor = Color.Red;
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (pictureBox4.BackColor != Color.Green)
            {
                pictureBox4.BackColor = Color.Green;
            }
            else
            {
                pictureBox4.BackColor = Color.Red;
            }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            if (pictureBox7.BackColor != Color.Green)
            {
                pictureBox7.BackColor = Color.Green;
            }
            else
            {
                pictureBox7.BackColor = Color.Red;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (pictureBox2.BackColor != Color.Green)
            {
                pictureBox2.BackColor = Color.Green;
            }
            else
            {
                pictureBox2.BackColor = Color.Red;
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (pictureBox3.BackColor != Color.Green)
            {
                pictureBox3.BackColor = Color.Green;
            }
            else
            {
                pictureBox3.BackColor = Color.Red;
            }
        }
    }
}
